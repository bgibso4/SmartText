# Smart Text v1.0.0

This is an android app which was developed to send text messages at a future time. There are certain use cases in which this application was intenationally designed for. The primary use case is sending a text to your friend to let them know you have arrived before you have even left. This is accompliished by setting the time you want the text to be sent to your expected eta. Still in the beggining stages of development with the product expected to launch within the next month.  

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

Gson library has been used to create json objects from class. Getting gson imported is fairly straight forward. This link should get you started. 
http://blog.madadipouya.com/2015/09/21/how-to-add-gson-library-to-android-studio-project/ 


## Authors

* **Ben Gibson** - *Initial work* 
* **Luke Medeiros** 
